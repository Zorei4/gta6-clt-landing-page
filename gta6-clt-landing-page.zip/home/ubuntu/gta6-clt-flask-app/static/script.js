// Função para copiar a chave PIX
function copyPixKey() {
    const pixInput = document.getElementById('pix-key');
    const copyBtn = document.getElementById('copy-btn');
    const successMessage = document.getElementById('success-message');
    
    // Seleciona e copia o texto
    pixInput.select();
    pixInput.setSelectionRange(0, 99999); // Para dispositivos móveis
    
    try {
        // Tenta usar a API moderna de clipboard
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(pixInput.value).then(() => {
                showSuccessMessage();
            }).catch(() => {
                // Fallback para o método antigo
                document.execCommand('copy');
                showSuccessMessage();
            });
        } else {
            // Fallback para navegadores mais antigos
            document.execCommand('copy');
            showSuccessMessage();
        }
    } catch (err) {
        console.error('Erro ao copiar:', err);
        // Ainda assim mostra a mensagem, pois o usuário pode ter copiado manualmente
        showSuccessMessage();
    }
    
    function showSuccessMessage() {
        // Mostra a mensagem de sucesso
        successMessage.classList.remove('hidden');
        
        // Adiciona feedback visual ao botão
        const originalText = copyBtn.innerHTML;
        copyBtn.innerHTML = `
            <svg class="copy-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" fill="currentColor"/>
            </svg>
            COPIADO!
        `;
        
        copyBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
        
        // Volta ao estado original após 3 segundos
        setTimeout(() => {
            copyBtn.innerHTML = originalText;
            copyBtn.style.background = 'linear-gradient(135deg, #8b5cf6, #06b6d4)';
            successMessage.classList.add('hidden');
        }, 3000);
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    const copyBtn = document.getElementById('copy-btn');
    const pixInput = document.getElementById('pix-key');
    
    // Adiciona evento de clique no botão copiar
    copyBtn.addEventListener('click', copyPixKey);
    
    // Adiciona evento de clique no input para facilitar a seleção
    pixInput.addEventListener('click', function() {
        this.select();
    });
    
    // Adiciona suporte para tecla Enter no input
    pixInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            copyPixKey();
        }
    });
    
    // Adiciona animações suaves aos elementos quando entram na viewport
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observa elementos para animação
    const animatedElements = document.querySelectorAll('.pix-container, .support-text, .footer');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Adiciona efeito de partículas no fundo (opcional)
function createParticles() {
    const particlesContainer = document.createElement('div');
    particlesContainer.className = 'particles';
    particlesContainer.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
    `;
    
    document.body.appendChild(particlesContainer);
    
    for (let i = 0; i < 50; i++) {
        const particle = document.createElement('div');
        particle.style.cssText = `
            position: absolute;
            width: 2px;
            height: 2px;
            background: rgba(139, 92, 246, 0.5);
            border-radius: 50%;
            animation: float ${Math.random() * 3 + 2}s ease-in-out infinite;
            left: ${Math.random() * 100}%;
            top: ${Math.random() * 100}%;
            animation-delay: ${Math.random() * 2}s;
        `;
        
        particlesContainer.appendChild(particle);
    }
}

// Adiciona CSS para animação das partículas
const style = document.createElement('style');
style.textContent = `
    @keyframes float {
        0%, 100% {
            transform: translateY(0px) rotate(0deg);
            opacity: 0.5;
        }
        50% {
            transform: translateY(-20px) rotate(180deg);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);

// Inicializa as partículas quando a página carrega
document.addEventListener('DOMContentLoaded', createParticles);

// Adiciona suporte para PWA (Progressive Web App) - opcional
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Registra service worker se disponível
        // navigator.serviceWorker.register('/sw.js');
    });
}

