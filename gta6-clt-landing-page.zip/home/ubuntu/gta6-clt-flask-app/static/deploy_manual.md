# Manual de Deploy - Landing Page DESAFIO GTA 6 CLT

## Arquivos do Projeto

O projeto da landing page está localizado em `/home/ubuntu/gta6-clt-landing/` e contém os seguintes arquivos:

### Arquivos Principais
- `index.html` - Estrutura HTML da landing page
- `styles.css` - Estilos CSS com responsividade e animações
- `script.js` - JavaScript para funcionalidade de copiar PIX
- `background.png` - Imagem de fundo com tema de games

### Arquivos de Documentação
- `test_report.md` - Relatório completo de testes
- `design_concept.md` - Conceito de design da landing page
- `copywriting.md` - Arquitetura da informação e copywriting

## Opções de Deploy

### 1. Deploy Simples (Hospedagem Estática)
A landing page é totalmente estática e pode ser hospedada em qualquer servidor web ou serviço de hospedagem estática:

**Serviços Recomendados:**
- **Netlify** (gratuito) - Arraste e solte a pasta do projeto
- **Vercel** (gratuito) - Conecte com GitHub ou upload direto
- **GitHub Pages** (gratuito) - Para repositórios públicos
- **Firebase Hosting** (gratuito) - Google Firebase
- **Surge.sh** (gratuito) - Deploy via linha de comando

### 2. Deploy via FTP/SFTP
Para servidores tradicionais:
1. Faça upload de todos os arquivos para a pasta raiz do seu domínio
2. Certifique-se de que o `index.html` está na raiz
3. Verifique se as permissões dos arquivos estão corretas (644 para arquivos, 755 para pastas)

### 3. Deploy em Servidor Apache/Nginx
Para servidores próprios:
1. Copie os arquivos para o diretório do servidor web
2. Configure o virtual host (se necessário)
3. Reinicie o servidor web

## Instruções Específicas

### Para Netlify (Recomendado)
1. Acesse [netlify.com](https://netlify.com)
2. Faça login ou crie uma conta gratuita
3. Arraste a pasta `gta6-clt-landing` para a área de deploy
4. Aguarde o deploy automático
5. Sua landing page estará disponível em uma URL fornecida pelo Netlify

### Para Vercel
1. Acesse [vercel.com](https://vercel.com)
2. Faça login ou crie uma conta gratuita
3. Clique em "New Project"
4. Faça upload da pasta do projeto
5. Configure o nome do projeto (opcional)
6. Clique em "Deploy"

### Para GitHub Pages
1. Crie um repositório no GitHub
2. Faça upload dos arquivos do projeto
3. Vá em Settings > Pages
4. Selecione a branch main como source
5. Sua landing page estará disponível em `username.github.io/repository-name`

## Configurações Adicionais

### Meta Tags para SEO (Opcional)
Adicione estas meta tags no `<head>` do `index.html`:

```html
<meta name="description" content="DESAFIO GTA 6 CLT - Ajude um trabalhador CLT a jogar GTA 6 no lançamento">
<meta name="keywords" content="GTA 6, CLT, trabalhador, games, PIX, doação">
<meta property="og:title" content="DESAFIO GTA 6 CLT">
<meta property="og:description" content="R$1 seu pode colocar um trabalhador CLT no GTA 6 no dia do lançamento">
<meta property="og:image" content="background.png">
<meta property="og:type" content="website">
```

### Favicon (Opcional)
Para adicionar um ícone personalizado:
1. Crie um arquivo `favicon.ico` (16x16 ou 32x32 pixels)
2. Adicione no `<head>`: `<link rel="icon" href="favicon.ico" type="image/x-icon">`

### Analytics (Opcional)
Para rastrear visitantes, adicione o código do Google Analytics antes do `</head>`.

## Domínio Personalizado

### Para usar um domínio próprio:
1. Configure os DNS do seu domínio para apontar para o serviço de hospedagem
2. No painel do serviço (Netlify/Vercel), adicione o domínio personalizado
3. Configure SSL/HTTPS (geralmente automático)

## Manutenção

### Atualizações Futuras:
- Para alterar a chave PIX: edite o valor no `index.html` linha 23
- Para alterar textos: edite o conteúdo no `index.html`
- Para alterar cores/design: edite o arquivo `styles.css`

### Backup:
- Mantenha uma cópia local dos arquivos
- Use controle de versão (Git) para histórico de mudanças

## Suporte

A landing page foi desenvolvida com tecnologias padrão (HTML5, CSS3, JavaScript) e é compatível com todos os navegadores modernos. Não requer servidor especial ou configurações complexas.

**Requisitos Mínimos do Servidor:**
- Suporte a arquivos estáticos (HTML, CSS, JS, imagens)
- HTTPS recomendado (mas não obrigatório)
- Sem necessidade de PHP, banco de dados ou outras tecnologias server-side

